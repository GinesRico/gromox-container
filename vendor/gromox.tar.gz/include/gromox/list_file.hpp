#pragma once
#include <cstdint>
#include <cstdio>
#include <memory>
#include <string>
#include <gromox/defs.h>
#include <gromox/fileio.h>

struct GX_EXPORT LIST_FILE {
	void *get_list() { return pfile.get(); }
	size_t get_size() const { return item_num; }

	std::unique_ptr<FILE, gromox::file_deleter> file_ptr;
    char        format[32];
    int         type_size[32];
    int         type_num;
	size_t item_size = 0, item_num = 0;
	std::unique_ptr<char[]> pfile;
};

enum {
	EMPTY_ON_ABSENCE = 0,
	ERROR_ON_ABSENCE,
};

extern GX_EXPORT std::unique_ptr<LIST_FILE> list_file_initd(const char *filename, const char *sdlist, const char *format, unsigned int mode = EMPTY_ON_ABSENCE);
